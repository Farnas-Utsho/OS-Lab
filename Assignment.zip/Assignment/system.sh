#! /bin/bash

#Teacher log in system

read -p  "Enter username : " username
read -sp "Enter Password :  " password

echo 
if grep "^$username $password$" teachersInfo.txt ;then 
	echo " Log in successful "
	echo " Welcome $username "
		
	if [ -d $username ]; then #checking whether folder exist or not
		echo "$username already exist"
	else
	 mkdir "$username"	#if not then create
	fi	 	
else 
 echo "Invalid Information"
fi	
