#!/bin/bash

#Finding questions according to saved into id.txt file
find_question(){
	local serial="$1"
	local answer="$2"
	local question=$(grep "^$serial" questions.txt)
   if [ -n "$question" ]; then
 	
        echo "$question" 
     	read -p "$serial. Answer: " ans < /dev/tty #Answering the questions 
     	 word_count=$(echo "$ans" | wc -w)
       
        while [ "$word_count" -gt 3 ]; do # Check if the answer contains more than three words
            echo "Please provide an answer with at most two words."
            read -p "$serial. Answer: " ans < /dev/tty
            word_count=$(echo "$ans" | wc -w)
            done
     	echo "$serial Answer: $ans" >> "$answer"  #Here saving answers into a .txt file
     	else
        echo "Question not found"
    fi
    
    
}
#Checking grade
grade() {
    mark="$1"
    if (( mark >= 90 && mark <= 100 )); then
        grade="A"
    elif (( mark >= 80 && mark < 90 )); then
        grade="B+"
    elif (( mark >= 70 && mark < 80 )); then
        grade="B"
    elif (( mark >= 60 && mark < 70 )); then
        grade="C+"
    elif (( mark >= 50 && mark < 60 )); then
        grade="C"
    elif (( mark >= 40 && mark < 50 )); then
        grade="D"
    else
        grade="F"
    fi
    echo "Grade for $mark marks: $grade"
}


#Student login

read -p "Enter username: " username
read -sp "Enter Password: " password


filename="$username .txt"
answer="answer($username).txt" 


if grep -q "^$username $password$" studentsInfo.txt; then 
    echo "Welcome $username"
    if [ -e "$answer" ];then
 echo "Answer sheet exist"
 else touch "$answer"    #creating answer sheet for the iogged in  id 
 echo "Answer sheet created"
 
 fi

    if [ -e "$filename" ]; then 
        line_count=$(wc -l < "$filename")
        total_mark=100
        echo "Total Number : 100"
       	per_question=$((total_mark / line_count))
       echo "Each question carry: $per_question"
        fi
    if [ -e "$filename" ];then 
    
   	while IFS= read -r  line;do
 	find_question "$line" "$answer"  #fucntion for finding the related questions 
 	done < "$filename"
    else echo "Do not"
    fi
    
else 
    echo "Invalid Id and password"
fi



#Result generation  and adding to result.txt
right=0
wrong=0


while IFS= read -r ans; do
    if grep -q "^$ans" answers.txt; then
        right=$((right+1))
        echo "right : "$right""

    else  
        wrong=$((wrong+1))
    fi
done < "$answer"

obtained_mark=$((right * per_question))
echo "Total obtained mark : $obtained_mark"
obtained_grade=(grade "$obtained_mark")

echo " StudentID: $username , Obtained mark: $obtained_mark, Grade: $obtained_grade" >> result.txt












