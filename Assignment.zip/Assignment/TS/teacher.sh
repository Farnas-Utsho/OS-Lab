#!/bin/bash
question_number() {
  local user_input=$1
  local max=$2
  local numbers=()

  for ((i = 0; i < user_input; i++)); do
    rand=$(( (RANDOM % max) + 1 ))


    while [[ " ${numbers[@]} " =~ " $rand " ]]; do #checking whether the question number is repeated or not 
      rand=$(( (RANDOM % max) + 1 ))
    done

    numbers+=($rand)
  done
for num in "${numbers[@]}"; do
    echo "$num"
  done

  
}


file_name="studentsID.txt"
while IFS= read -r  line; do 
   echo "$line"
   touch "$line.txt"
   read -p "Enter how many questions you want to add (1 to 34) for $line: " n < /dev/tty		
   question_number $n 34 > "$line.txt" # function for generating question
done < "$file_name"



 









